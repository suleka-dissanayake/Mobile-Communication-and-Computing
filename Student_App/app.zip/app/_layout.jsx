import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Stack } from 'expo-router'

const RootLayout = () => {
  return (
    <View style={styles.container}>
        <Stack/>
      <Text>Footer</Text>
    </View>
  )
}

export default RootLayout
const styles = StyleSheet.create({
    container:{
        flex:1,
    }
})